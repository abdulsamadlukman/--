# Module 4 - Backend Development: Micro Lessons
> For use with AI practice question generation. Beginner level only.

---

## Topic 1: Consuming External APIs with Python

**Title:** Consuming External APIs with Python

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will make GET requests to a free public API using the requests library, read status codes, parse JSON responses (including nested data), pass query parameters correctly, and handle errors with try/except and timeouts.

**Description for AI:**
This topic teaches students to consume a third-party API from Python for the first time, using the free Countries Now API (countriesnow.space) — no API key required. Students install requests, make a GET request, check response.status_code before trusting the data, call response.json() to parse the body, and access nested fields (the API wraps results in a "data" key, and one endpoint returns a list of year/value population records nested inside that). Students learn to use params= instead of building URLs by hand — critical for values containing spaces, like "south africa". They also learn to catch a real 404 for an invalid country name, and to build a professional call_safely()-style function with try/except covering requests.HTTPError, requests.ConnectionError, and requests.Timeout, always setting a timeout so a slow server can't hang the app forever. Nigerian context: comparing Nigeria, Ghana, Kenya, and Senegal by capital and currency; combining several focused API calls into one clean Nigeria country summary, since this particular API has no single "everything about this country" endpoint.

**Common Mistakes:**
- Calling .json() before checking response.status_code, so a failed request's error page gets parsed as if it were valid data
- Building URLs with an f-string instead of params=, which breaks on values containing spaces (e.g. "south africa")
- Assuming every API's data lives at the top level of the response — this API nests everything under a "data" key
- Forgetting to set a timeout on requests.get(), so a slow or unreachable server hangs the request indefinitely
- Catching only the general Exception instead of the specific requests error types, hiding what actually went wrong

---

## Topic 2: Working with API Keys & Authentication

**Title:** Working with API Keys & Authentication

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will store API credentials safely in a .env file, load them with python-dotenv, pass a key in the Authorization header using the Bearer scheme, and handle 401 and 429 error responses correctly.

**Description for AI:**
Students learn the standard Bearer token authentication pattern used by most modern APIs, building on the credential style from Module 2 (OPENAI_API_KEY, MODEL_NAME, OPENAI_BASE_URL). They store all three values in .env, load them with load_dotenv() and os.getenv(), and build the Authorization header manually as f"Bearer {api_key}" — the same header format the openai library builds automatically behind the scenes. Students only print the first 10 characters of a key to confirm it loaded, never the full value. They build the request URL from base_url rather than hardcoding a specific provider's address, so the same code works against different OpenAI-compatible endpoints. They deliberately trigger a 401 with a wrong key to see what an authentication failure looks like, and learn that some non-OpenAI providers return 403 instead of 401 for a bad key — a difference worth checking against the specific provider's docs rather than assuming. Nigerian context: this groundwork directly sets up secure credential handling for a Nigerian fintech or SaaS backend, where a leaked key is a real production incident.

**Common Mistakes:**
- Printing the full API key to the console or a shared screen during debugging
- Hardcoding a specific host's URL instead of reading base_url from .env, so the code silently ignores what a student's own .env actually points to
- Forgetting the word "Bearer" before the key in the Authorization header, or misspelling it
- Assuming a wrong key always returns 401 — some providers return 403 instead
- Committing a real .env file to Git instead of adding it to .gitignore

---

## Topic 3: Introduction to FastAPI

**Title:** Introduction to FastAPI

**Programming Language:** Python

**Coding Exercise:** Yes (terminal + Python, no notebook — FastAPI runs as a live server)

**Learning Objective:**
Students will install FastAPI and uvicorn, write their first GET endpoint, run the development server with --reload, and explore the automatic Swagger documentation at /docs, including setting a custom response status code.

**Description for AI:**
This is students' first live backend server. They install fastapi and uvicorn, write a FastAPI app instance and a single @app.get("/") endpoint returning a Python dict (FastAPI converts it to JSON automatically), and run it with uvicorn main:app --reload. They explore /docs — automatically generated from their code, no extra work required — and test endpoints directly from the browser using "Try it out". They add more endpoints (/health, /cities) and a path parameter endpoint (/cities/{city_name}) that looks up a Nigerian city in a small dictionary, first noticing it always returns status 200 even when the city isn't found, then fixing that by injecting a Response object and manually setting response.status_code = 404. Students learn that --reload restarts the whole server process on every save — a fact that matters a great deal starting next topic, when the app has real state to lose. Nigerian context: the app is framed as the beginning of "NaijaBiz API", and the city lookup covers Lagos, Abuja, and Kano.

**Common Mistakes:**
- Forgetting --reload, so code changes require manually restarting uvicorn every time
- Returning a plain dict for an error case and expecting it to produce a 404 automatically — the status code must be set explicitly
- Running uvicorn from the wrong folder, causing "could not import module main"
- Confusing /docs (interactive Swagger UI) with /redoc (read-only alternative style) — both exist, both show the same endpoints
- Not noticing that address already in use on port 8000 means another running server needs to be stopped first, not a code bug

---

## Topic 4: Building API Endpoints with FastAPI

**Title:** Building API Endpoints with FastAPI

**Programming Language:** Python

**Coding Exercise:** Yes (terminal + Python)

**Learning Objective:**
Students will build a full in-memory CRUD API — GET with optional query filtering, GET one with a path parameter and 404 handling, POST with a 201 status, PUT for partial replacement, and DELETE with a 204 response — and understand why `--reload` wipes in-memory data on every save.

**Description for AI:**
Students build a complete products CRUD API on top of a plain Python list acting as a temporary in-memory database. Reading endpoints use raise HTTPException(status_code=404, ...) rather than returning an error dict directly. The create endpoint checks for an existing product with the same name before creating a new one, rejecting duplicates with a 400 — a check performed in the application code, not by a database constraint, since the underlying table has no uniqueness rule on name. New ids are generated with max(existing ids) + 1, not len(list) + 1, since a count-based id breaks the moment anything has ever been deleted. Students explicitly watch --reload wipe their accumulated test data mid-demo (predicting what will happen before it does), then connect that directly to why Week 8 replaces this list with a real MySQL database — data that survives a restart. Nigerian context: Indomie Noodles, MTN Data SIM, Power Bank, and Dangote Cement as the running product catalogue for "NaijaBiz API".

**Common Mistakes:**
- Generating new ids with len(list) + 1 instead of max(existing ids) + 1, which produces duplicate ids once a delete has ever happened
- Forgetting that saving main.py while --reload is active resets any in-memory list back to its original hardcoded state
- Using model_dump() instead of model_dump(exclude_unset=True) on a PUT endpoint, which overwrites untouched fields with None
- Returning a dict from a DELETE endpoint instead of Response(status_code=204), which produces a 200 with a body instead of a clean 204
- Assuming the max() call is safe on an empty list — it raises an error if no items exist yet

---

## Topic 5: Request & Response Models with Pydantic

**Title:** Request & Response Models with Pydantic

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will replace raw dict parameters with Pydantic BaseModel classes for both requests and responses, use Field() for validation constraints, and understand that response models control what data leaves an endpoint — not just what format it's in.

**Description for AI:**
Students first see the problem this topic solves: an endpoint typed as dict accepts literally any JSON body, including garbage with no name or price, and still returns 201. Replacing dict with a ProductCreate(BaseModel) class gives automatic 422 validation for missing fields, wrong types, and out-of-range values (Field(gt=0) for price, Field(min_length=2) for name), with FastAPI generating a full documented schema in /docs for free. A second model, ProductUpdate, makes every field Optional so PUT can support true partial updates. The most important idea in this topic is response_model: without it, FastAPI happily serializes every column on a database object — description, created_at, eventually a password hash — with no error and no warning. A ProductResponse class that simply omits fields is what keeps those fields out of every response, regardless of what the underlying object contains. Nigerian context: continues the NaijaBiz API product catalogue, validating fields like Dangote Cement 50kg's price and stock.

**Common Mistakes:**
- Assuming Pydantic will reject a request just because a field is technically wrong type without a Field() constraint like gt=0 actually being declared
- Believing response_model only changes formatting — it also silently prevents fields from leaking, which becomes critical once a password_hash field exists on a model
- Forgetting from_attributes = True (formerly orm_mode) in a schema's Config, so it fails to read attributes off a SQLAlchemy object
- Leaving an old, unfiltered version of an endpoint in the file after "adding" a response_model version — FastAPI keeps whichever route was registered first, so the new one is silently never called
- Using Optional[str] without = None as a default, which still makes the field required despite being marked Optional

---

## Topic 6: Introduction to Databases & MySQL

**Title:** Introduction to Databases & MySQL

**Programming Language:** SQL (via the MySQL terminal — no Python in this topic)

**Coding Exercise:** Yes

**Learning Objective:**
Students will connect to MySQL from the terminal, create a database and table, insert records, run SELECT queries with WHERE, ORDER BY, and LIMIT, and safely UPDATE and DELETE specific rows using WHERE.

**Description for AI:**
This topic is pure SQL, deliberately with no Python or FastAPI, so students focus entirely on how a real database behaves. They connect with mysql -u root -p, create a database and a customers table with AUTO_INCREMENT, NOT NULL, UNIQUE, and DEFAULT CURRENT_TIMESTAMP constraints, insert three Nigerian customers, and practice filtering, sorting, and limiting results. The most important lesson is safety: always SELECT the target row first to confirm it's the right one before running UPDATE or DELETE, and never run either without a WHERE clause — the guide shows, without executing it, what would happen to every row if WHERE were omitted. Students also reconnect to MySQL after disconnecting to see that their data is still there — the core difference between a database and the in-memory Python list used in Week 7's demos. Nigerian context: Amara Nwosu (Lagos), Chidi Okafor (Abuja), and Fatima Bello (Kano) as the customer records.

**Common Mistakes:**
- Running UPDATE or DELETE without a WHERE clause, which affects every row in the table
- Using double quotes instead of single quotes around string values in SQL, causing a syntax error
- Forgetting to run USE database_name before querying, resulting in "no database selected"
- Assuming DELETE FROM customers WHERE id = 3 run twice will error the second time — it just reports "0 rows affected" since the row is already gone
- Not realising ids are permanently gone after a row is deleted — AUTO_INCREMENT does not reuse deleted ids

---

## Topic 7: MySQL Setup & Database Design

**Title:** MySQL Setup & Database Design

**Programming Language:** SQL

**Coding Exercise:** Yes

**Learning Objective:**
Students will design and build a 4-table relational schema with foreign keys, correct data types for money and text, and verify referential integrity by intentionally triggering a foreign key violation.

**Description for AI:**
Students design the naija_backend schema that every later topic in the module builds on: users, products, orders, and order_items, with foreign keys linking orders to users and order_items to both orders and products. They use utf8mb4 character encoding (required for full Unicode support, including Nigerian language characters), DECIMAL(10,2) for all money fields (never FLOAT, which introduces rounding errors), and deliberately try to insert an order for a user id that doesn't exist to see MySQL reject it with a real foreign key constraint error before inserting a valid one. They also practice ALTER TABLE to add and remove a column without losing existing data. Nigerian context: Indomie Noodles, MTN 10GB Data Bundle, and Dangote Cement 50kg as products; Amara Nwosu as the first user and order.

**Common Mistakes:**
- Creating a child table (like orders) before its parent table (users) exists, causing a foreign key creation error
- Using FLOAT instead of DECIMAL for money fields, which can produce subtle rounding errors over many transactions
- Forgetting a comma between column definitions in CREATE TABLE, or leaving a trailing comma after the last one
- Assuming ALTER TABLE requires recreating the whole table and losing data — it does not
- Not testing the foreign key constraint deliberately, and only discovering it exists when a real insert fails later

---

## Topic 8: Database Integration with FastAPI

**Title:** Database Integration with FastAPI

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will connect FastAPI to MySQL using SQLAlchemy, define an ORM model, write a get_db() dependency for one-session-per-request, and add a Pydantic response schema to control exactly what a database record exposes.

**Description for AI:**
Students install sqlalchemy and pymysql, then build database.py (engine, SessionLocal, Base — using declarative_base from sqlalchemy.orm, not the older deprecated sqlalchemy.ext.declarative path) and models.py, where a Product class maps directly to the products table built in the previous topic. They write get_db() as a generator using yield inside a try/finally, and learn why: SQLAlchemy sessions aren't thread-safe, so sharing one global session across concurrent requests risks corrupting data — one session per request, always closed, is the safe pattern. The key discovery in this topic is that returning a raw SQLAlchemy object from an endpoint without a response_model doesn't crash — it returns 200 and silently includes every column, including ones nobody intended to expose. Adding a ProductOut schema with response_model= is what actually controls exposure, foreshadowing why this matters enormously once a password_hash field exists on a User model in a later topic. Nigerian context: reads real product data (Indomie, MTN Data Bundle, Dangote Cement) that instructors inserted directly into MySQL in the previous topic.

**Common Mistakes:**
- Importing declarative_base from sqlalchemy.ext.declarative instead of sqlalchemy.orm — the old path still works but prints a deprecation warning every run
- Expecting a "not JSON serializable" crash when skipping response_model — on current FastAPI it doesn't crash, it just leaks every field, which is the more important problem to catch
- Forgetting from_attributes = True in a schema's Config, breaking the conversion from a SQLAlchemy object to a Pydantic response
- Running uvicorn from outside the naija-backend/ folder, causing "No module named 'database'"
- Not checking that MySQL is actually running before troubleshooting a connection error in the Python code

---

## Topic 9: CRUD Operations with a Database

**Title:** CRUD Operations with a Database

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will implement full database-backed CRUD — POST with db.add()/commit()/refresh(), pagination with skip and limit, PUT with model_dump(exclude_unset=True), and DELETE with a 204 response — and add a User model in preparation for authentication.

**Description for AI:**
Students extend the read-only Topic 8 API into a fully writable one, now persisted in MySQL instead of an in-memory list. POST /products checks whether a product with the same name already exists before inserting — an application-level check-then-create pattern, not a database constraint — because the products table has no uniqueness rule on name; this is the same pattern used later in the module for duplicate email registration. GET /products gains category filtering plus skip/limit pagination, framed around why an unlimited GET /products on a Jumia-scale table would be dangerous. PUT uses model_dump(exclude_unset=True) so only fields actually sent by the client get updated. Because everything now lives in MySQL rather than a Python list, --reload no longer wipes data — a direct payoff of the database work from Topics 6-8. The topic ends by adding a User model (with a password_hash column) and a UserOut schema that deliberately excludes it, setting up registration in the next topic. Nigerian context: continues the same NaijaBiz product catalogue.

**Common Mistakes:**
- Wrapping the duplicate check in a try/except around IntegrityError instead of checking first — this only works if a real database constraint exists, and here it doesn't
- Using model_dump() instead of model_dump(exclude_unset=True) on PUT, silently overwriting fields the client never sent
- Forgetting status_code=status.HTTP_204_NO_CONTENT on both the decorator and the Response() call for DELETE
- Not importing the new User model before calling Base.metadata.create_all(), so the users table never gets created
- Assuming an older Pydantic v1 method like .dict() still works — current Pydantic uses .model_dump()

---

## Topic 10: Authentication Concepts

**Title:** Authentication Concepts

**Programming Language:** Python (standalone script — no FastAPI in this topic)

**Coding Exercise:** Yes

**Learning Objective:**
Students will hash and verify passwords with bcrypt directly, observe that hashing the same password twice produces different results, and inspect a JWT's three parts (header, payload, signature) at jwt.io, including what tampering with it does.

**Description for AI:**
This is a conceptual, code-light topic building intuition before Topics 11-13 turn it into working endpoints. Students use bcrypt directly (bcrypt.hashpw() and bcrypt.checkpw()) rather than the older passlib wrapper library, since passlib is unmaintained and actually crashes against current bcrypt releases on the very first password hashed — using bcrypt directly avoids that fragility entirely and is also simpler to explain, with no wrapper class involved. They hash the same password twice and see two different results (the random salt at work, embedded directly in the hash string), and confirm a weak password produces a hash exactly as long as a strong one — bcrypt reveals nothing about password strength. They paste a sample JWT into jwt.io, examine its three sections, and edit the payload directly in the browser to watch the signature become invalid — the concrete proof that a JWT's security comes from the signature, not from hiding the payload. They also generate a proper random SECRET_KEY with Python's secrets module, contrasted against obviously weak examples like "secret" or "naijashop2024".

**Common Mistakes:**
- Calling bcrypt.hashpw() with a plain string instead of bytes — it requires .encode() on the password first
- Assuming two hashes of the same password should look identical — the random salt guarantees they won't
- Believing a JWT's payload is encrypted and hidden — it's only base64-encoded and fully readable by anyone with the token
- Expecting jwt.io to show "Valid Signature" for the sample token — it uses a different secret key than the one used to sign it, so it will always show invalid there, which is expected
- Choosing a short or guessable SECRET_KEY like a name or date instead of a long random one from secrets.token_hex()

---

## Topic 11: Implementing User Registration & Login

**Title:** Implementing User Registration & Login

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will build auth.py with hash_password() and verify_password(), a POST /register endpoint with duplicate-email checking, and a POST /login endpoint that verifies credentials and returns a placeholder token.

**Description for AI:**
Students turn Topic 10's concepts into a real, working feature. auth.py wraps bcrypt.hashpw()/checkpw() in two small functions — hash_password() decodes the resulting bytes to a plain string since the password_hash column is a VARCHAR, and verify_password() encodes the stored string back to bytes for comparison. POST /register checks for an existing email before hashing anything (saving the compute cost of hashing a password that's going to be rejected anyway), then saves the new user with response_model=UserOut so the hash never appears in the response. Students verify the stored hash directly in MySQL (starting with $2b$12$, proof the plain password was never saved). POST /login checks the email exists and the password verifies, returning 401 with the identical message for both a wrong password and an unregistered email — deliberately, to prevent account enumeration. The token returned at this stage is still a placeholder string like "user_id_1", explicitly flagged as forgeable — Topic 12 replaces it with a real JWT. Nigerian context: Amara Nwosu and Chidi Okafor as the two registered NaijaBiz AI users.

**Common Mistakes:**
- Running the duplicate-email check after hashing the password instead of before, wasting compute on a rejected request
- Returning the same detail message inconsistency between wrong-password and unknown-email cases, accidentally revealing which emails are registered
- Naming the model column something other than password_hash without updating every place that references it
- Forgetting that a placeholder token like "user_id_1" is trivially forgeable by anyone — that's exactly the gap Topic 12 closes
- Testing only the success path and never testing wrong password or unregistered email, missing that both should return 401 with the same message

---

## Topic 12: JWT Authentication in FastAPI

**Title:** JWT Authentication in FastAPI

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will install PyJWT, add create_access_token() and get_current_user() to auth.py, update login to return a real signed JWT, protect an endpoint with Depends(get_current_user), and test authentication using the Authorize button in /docs.

**Description for AI:**
Students replace Topic 11's placeholder token with a real signed JWT, using PyJWT (the actively maintained, currently-recommended library — not python-jose, which also works but is less actively developed). create_access_token() builds a payload containing sub (user id), email, and role, adds an exp claim as a datetime object (PyJWT converts it to a timestamp automatically), and signs it with jwt.encode() using a SECRET_KEY loaded from .env. get_current_user() reads the Authorization header via OAuth2PasswordBearer, decodes and verifies the token with jwt.decode(), and raises a 401 for any failure — expired, tampered, or malformed — all caught by the single jwt.PyJWTError exception class. Students test the full loop: log in, copy the token, decode it at jwt.io to see the real payload and expiry, then use the /docs Authorize button to call a protected GET /me endpoint, testing it with no token, a valid token, and a deliberately tampered one. Nigerian context: continues the NaijaBiz AI user base — Amara's own profile is what GET /me returns.

**Common Mistakes:**
- Forgetting load_dotenv() before reading SECRET_KEY, resulting in a None value used to sign every token
- Importing get_current_user in main.py's imports but forgetting create_access_token, so login still returns the old placeholder string
- Pasting the full JSON login response into the /docs Authorize field instead of just the access_token string value
- Assuming jwt.io showing "Invalid Signature" for a real token means something is broken — it's expected, since jwt.io doesn't have the server's SECRET_KEY
- Not knowing that changing SECRET_KEY in .env invalidates every previously issued token, requiring every user to log in again

---

## Topic 13: Protecting Routes & Role-Based Access

**Title:** Protecting Routes & Role-Based Access

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will add a require_admin dependency built on top of get_current_user, apply it to admin-only endpoints, promote a user's role directly in MySQL, and demonstrate the full 401 → 403 → success access chain on the same endpoint.

**Description for AI:**
This topic distinguishes authentication (who is this user?) from authorisation (what are they allowed to do?). require_admin() calls get_current_user() via Depends() first — authentication always runs before authorisation — then checks the decoded role field, raising 403 Forbidden if it isn't "admin". Students apply this to DELETE /products (and later, GET /admin/users), promote a second user to admin directly via a MySQL UPDATE, then walk the same DELETE endpoint through all three outcomes: no token (401, authentication never even started), a valid token with the wrong role (403, authentication passed but authorisation failed), and a valid admin token (204, success). They also build a /dashboard endpoint that reads role straight out of the decoded token to return a different feature set per user, without needing a second get_current_user-style lookup. Nigerian context: Amara (regular user) and Chidi (promoted to admin) exercising the full access-control chain on the NaijaBiz AI product catalogue.

**Common Mistakes:**
- Expecting a role mismatch to produce 401 instead of 403 — 401 means "I don't know who you are", 403 means "I know who you are, and you're not allowed"
- Forgetting to log in again after promoting a user's role in MySQL — the old JWT still has the old role baked into its payload until a fresh token is issued
- Adding require_admin to the function signature but forgetting to update the import line in main.py
- Believing the /admin/ prefix in a URL enforces anything on its own — it's just a naming convention; the actual protection comes from Depends(require_admin)
- Confusing SQLAlchemy's == True filter syntax as somehow broken or unnecessary — bare Job.is_active and Job.is_active == True behave identically in SQLAlchemy, both are correct
