# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what main.py should look like at the END of this topic's demo,
# after following demo-guide.md (Parts 1 through 6) and typing the code
# live as instructed. Use this to check your file if something isn't
# working, or to catch back up if you fell behind in class.
#
# Remember: every time you save this file while uvicorn --reload is
# running, the server restarts and `products` resets to the three
# items below — that's expected, not a bug (see the demo guide).
#
# Run with: uvicorn main:app --reload

from fastapi import FastAPI, HTTPException, Response
from typing import Optional

app = FastAPI()

products = [
    {"id": 1, "name": "Indomie Noodles", "price": 150, "category": "food", "stock": 500},
    {"id": 2, "name": "MTN Data SIM", "price": 1000, "category": "telecoms", "stock": 200},
    {"id": 3, "name": "Power Bank 20000mAh", "price": 8500, "category": "electronics", "stock": 50},
]


@app.get("/products")
def get_products(category: Optional[str] = None):
    if category:
        return [p for p in products if p["category"] == category]
    return products


@app.get("/products/{product_id}")
def get_product(product_id: int):
    for product in products:
        if product["id"] == product_id:
            return product
    raise HTTPException(status_code=404, detail=f"Product {product_id} not found")


@app.post("/products", status_code=201)
def create_product(product: dict):
    product["id"] = max(p["id"] for p in products) + 1
    products.append(product)
    return product


@app.put("/products/{product_id}")
def update_product(product_id: int, updated_data: dict):
    for i, product in enumerate(products):
        if product["id"] == product_id:
            updated_data["id"] = product_id
            products[i] = updated_data
            return products[i]
    raise HTTPException(status_code=404, detail=f"Product {product_id} not found")


@app.delete("/products/{product_id}", status_code=204)
def delete_product(product_id: int):
    for i, product in enumerate(products):
        if product["id"] == product_id:
            products.pop(i)
            return Response(status_code=204)
    raise HTTPException(status_code=404, detail=f"Product {product_id} not found")
