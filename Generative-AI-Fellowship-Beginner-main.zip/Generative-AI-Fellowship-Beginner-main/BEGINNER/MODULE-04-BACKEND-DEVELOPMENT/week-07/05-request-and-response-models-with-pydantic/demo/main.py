# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what main.py should look like at the END of this topic's demo,
# after following demo-guide.md (Parts 1 through 6) and typing the code
# live as instructed. Use this to check your file if something isn't
# working, or to catch back up if you fell behind in class.
#
# get_products and delete_product are unchanged from Topic 4 — this
# topic only touches create_product, update_product, and get_product.
#
# Run with: uvicorn main:app --reload

from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel, Field
from typing import Optional

app = FastAPI()


class ProductCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    price: float = Field(gt=0)
    category: str
    stock: int = Field(ge=0, default=0)


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    category: Optional[str] = None
    stock: Optional[int] = None


class ProductResponse(BaseModel):
    id: int
    name: str
    price: float
    category: str
    # stock intentionally excluded


products = [
    {"id": 1, "name": "Indomie Noodles", "price": 150.0, "category": "food", "stock": 500},
    {"id": 2, "name": "MTN Data SIM", "price": 1000.0, "category": "telecoms", "stock": 200},
]


@app.get("/products")
def get_products(category: Optional[str] = None):
    if category:
        return [p for p in products if p["category"] == category]
    return products


@app.get("/products/{product_id}", response_model=ProductResponse)
def get_product(product_id: int):
    for product in products:
        if product["id"] == product_id:
            return product
    raise HTTPException(status_code=404, detail="Product not found")


@app.post("/products", status_code=201)
def create_product(product: ProductCreate):
    new_product = product.model_dump()
    new_product["id"] = max(p["id"] for p in products) + 1
    products.append(new_product)
    return new_product


@app.put("/products/{product_id}")
def update_product(product_id: int, updated: ProductUpdate):
    for i, product in enumerate(products):
        if product["id"] == product_id:
            update_data = updated.model_dump(exclude_none=True)
            products[i].update(update_data)
            return products[i]
    raise HTTPException(status_code=404, detail="Product not found")


@app.delete("/products/{product_id}", status_code=204)
def delete_product(product_id: int):
    for i, product in enumerate(products):
        if product["id"] == product_id:
            products.pop(i)
            return Response(status_code=204)
    raise HTTPException(status_code=404, detail=f"Product {product_id} not found")
