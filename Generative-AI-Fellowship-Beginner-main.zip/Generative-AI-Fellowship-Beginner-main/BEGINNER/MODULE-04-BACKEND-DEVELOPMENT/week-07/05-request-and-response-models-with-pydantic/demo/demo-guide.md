﻿# Demo Guide - Request & Response Models with Pydantic
**Module 4, Topic 5 | Estimated duration: 35-40 minutes**

---

## What This Demo Teaches

- Defining Pydantic models with required and optional fields
- Using a model in a POST endpoint to replace dict
- Seeing automatic 422 validation when invalid data is sent
- Seeing the improved /docs schema with Pydantic
- Using response_model to filter what data is returned
- Adding Field validators for value constraints

---

## Setup - Before the Demo Starts

1. Continue from the `naija-backend/` folder from Topic 4
2. Server should be stopped - `CTRL+C`
3. We will update `main.py` progressively during the demo

> **Instructor note:** Part 3's `create_product` uses `max(p["id"] for p in products) + 1`, the same collision-safe pattern from Topic 4 — not `len(products) + 1`, which would break the first time a product has ever been deleted. Part 6 explicitly says to replace the existing `get_product` function rather than add a second one, since FastAPI would silently keep the first-registered route active and never call a duplicate.

---

## Demo Steps

### Part 1 - Show the Problem (5 min)

Start the server from Topic 4 as-is.

**In /docs - POST /products with this invalid body:**
```json
{"gibberish": "hello"}
```

> "Look - our API accepted this. It stored a 'product' with no name, no price, nothing. Status 201 - we told the client it was a success. This is wrong."

**GET /products - show the garbage stored in the list.**

Stop the server.

> "Pydantic fixes this. Let's update main.py."

---

### Part 2 - Define the Models (7 min)

**Update the top of main.py:**
```python
from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel, Field
from typing import Optional

app = FastAPI()

class ProductCreate(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    price: float = Field(gt=0)
    category: str
    stock: int = Field(ge=0, default=0)

class ProductUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    category: Optional[str] = None
    stock: Optional[int] = None

products = [
    {"id": 1, "name": "Indomie Noodles", "price": 150.0, "category": "food", "stock": 500},
    {"id": 2, "name": "MTN Data SIM", "price": 1000.0, "category": "telecoms", "stock": 200},
]
```

> "Two models: ProductCreate for POST requests - all fields required except stock. ProductUpdate for PUT requests - all fields optional so we can do partial updates."

---

### Part 3 - Update the POST Endpoint (5 min)

**Update the create_product function:**
```python
@app.post("/products", status_code=201)
def create_product(product: ProductCreate):
    new_product = product.model_dump()
    new_product["id"] = max(p["id"] for p in products) + 1
    products.append(new_product)
    return new_product
```

> "This is the same `max(...) + 1` pattern from Topic 4, not `len(products) + 1`. That distinction matters: `len()` only works if ids and count always stay in sync — the moment a product is ever deleted, `len()` can hand out an id that already belongs to a surviving product. `max(existing ids) + 1` never collides, because it's based on the highest id that has ever existed, not how many items happen to be left right now."

**Start the server and open /docs.**

> "Look at POST /products now. The request body section shows the full schema - name, price, category, stock - with their types and which are required."

---

### Part 4 - Test Validation (8 min)

**Test 1 - Valid request:**
```json
{"name": "Dangote Cement 50kg", "price": 7500, "category": "construction", "stock": 1000}
```
> "201. Works perfectly."

**Test 2 - Wrong type:**
```json
{"name": "Dangote Cement 50kg", "price": "expensive", "category": "construction"}
```
> "422. Read the error message - it tells us exactly: body → price → 'Input should be a valid number'."

**Test 3 - Missing required field:**
```json
{"price": 7500, "category": "construction"}
```
> "422. Missing 'name'. The error tells us exactly which field is missing."

**Test 4 - Invalid value (negative price):**
```json
{"name": "Test", "price": -500, "category": "food"}
```
> "422. Price must be greater than 0."

**Test 5 - Missing stock (should use default):**
```json
{"name": "Test Product", "price": 200, "category": "food"}
```
> "201. Stock was not provided - defaults to 0. The stored product shows stock: 0."

---

### Part 5 - Update the PUT Endpoint (5 min)

**Update the update_product function:**
```python
@app.put("/products/{product_id}")
def update_product(product_id: int, updated: ProductUpdate):
    for i, product in enumerate(products):
        if product["id"] == product_id:
            update_data = updated.model_dump(exclude_none=True)
            products[i].update(update_data)
            return products[i]
    raise HTTPException(status_code=404, detail="Product not found")
```

> "exclude_none=True means only fields the client actually sent are updated. Send just `{\"price\": 8500}` - only the price changes."

**Test - partial update:**
```json
{"price": 8500}
```

> "GET /products/1 - only the price changed. Name, category, stock are untouched. This is much better than the Topic 4 version that replaced the entire product."

---

### Part 6 - Response Model (5 min)

**Find the existing `get_product` function from Topic 4 and replace it entirely with this version** — don't paste this in as a second, separate function. FastAPI registers routes in the order they're defined, and `GET /products/{product_id}` already exists from Topic 4; if both versions are left in the file, the old one (which doesn't filter `stock`) stays active and this new one is silently never called.

```python
class ProductResponse(BaseModel):
    id: int
    name: str
    price: float
    category: str
    # stock intentionally excluded

@app.get("/products/{product_id}", response_model=ProductResponse)
def get_product(product_id: int):
    for product in products:
        if product["id"] == product_id:
            return product
    raise HTTPException(status_code=404, detail="Product not found")
```

**Test GET /products/1 - notice stock is not in the response.**

> "The product has a stock field. We chose not to show it to customers. FastAPI filters it out automatically because stock is not in ProductResponse."

> "If you test this and stock is still showing up, that's the sign the old Topic 4 function is still in the file somewhere above this one — search for `def get_product` and make sure there's only one."

---

## Common Student Issues to Watch For

| Issue | What to say |
|-------|-------------|
| `AttributeError: 'dict' object has no attribute 'model_dump'` | "You are still passing a dict to the function, not a Pydantic model. Check the type annotation is `ProductCreate`, not `dict`." |
| 422 on valid-looking request | "Check your Field validators - price must be gt=0, not gte=0. A price of 0 would fail gt=0." |
| `NameError: name 'Field' is not defined` | "Change the import to `from pydantic import BaseModel, Field` - you're using Field without importing it." |
| Response model not filtering fields | "Check that `response_model=ProductResponse` is in the decorator, not the function body — and check there isn't a second, older `get_product` function still in the file from Topic 4." |

---

## Week 7 Complete

Students now have a complete, validated FastAPI Products API with:
- 6 CRUD endpoints
- Pydantic validation on all input
- Correct status codes
- Response model filtering
- Automatic /docs schema

**Up Next:** Week 8 - Databases + Authentication. We connect to MySQL so data persists, and add user registration and JWT login.
