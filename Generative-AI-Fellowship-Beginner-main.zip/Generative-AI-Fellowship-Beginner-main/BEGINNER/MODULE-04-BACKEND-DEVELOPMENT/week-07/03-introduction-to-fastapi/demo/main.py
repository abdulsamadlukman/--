# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what main.py should look like at the END of this topic's demo,
# after following demo-guide.md (Parts 2, 5, and 6) and typing the code
# live as instructed. Use this to check your file if something isn't
# working, or to catch back up if you fell behind in class.
#
# Run with: uvicorn main:app --reload

from fastapi import FastAPI, Response

app = FastAPI()


@app.get("/")
def read_root():
    return {"message": "Welcome to NaijaBiz API", "status": "running"}


@app.get("/health")
def health_check():
    return {"status": "healthy", "version": "1.0"}


@app.get("/cities")
def get_nigerian_cities():
    return {
        "cities": ["Lagos", "Abuja", "Kano", "Port Harcourt", "Ibadan"]
    }


@app.get("/cities/{city_name}")
def get_city_info(city_name: str, response: Response):
    cities = {
        "lagos": {"state": "Lagos", "population": "15 million"},
        "abuja": {"state": "FCT", "population": "3 million"},
        "kano": {"state": "Kano", "population": "4 million"},
    }

    city_data = cities.get(city_name.lower())

    if city_data:
        return city_data
    else:
        response.status_code = 404
        return {"error": f"City '{city_name}' not found"}
