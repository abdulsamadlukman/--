# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what models.py should look like at the END of this topic's demo.
# database.py is unchanged from Topic 3 — see that topic's demo/ folder.

from sqlalchemy import Column, Integer, String, DECIMAL, Text, TIMESTAMP
from sqlalchemy.sql import func
from database import Base


class Product(Base):
    __tablename__ = "products"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    price       = Column(DECIMAL(10, 2), nullable=False)
    category    = Column(String(100), nullable=True)
    stock       = Column(Integer, default=0)
    created_at  = Column(TIMESTAMP, server_default=func.now())


class User(Base):
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(100), nullable=False)
    email         = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role          = Column(String(20), default="user")
    created_at    = Column(TIMESTAMP, server_default=func.now())
