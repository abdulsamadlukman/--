# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what models.py should look like at the END of this topic's demo.

from sqlalchemy import Column, Integer, String, DECIMAL, Text, TIMESTAMP
from sqlalchemy.sql import func
from database import Base


class Product(Base):
    __tablename__ = "products"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    price       = Column(DECIMAL(10, 2), nullable=False)
    category    = Column(String(100), nullable=True)
    stock       = Column(Integer, default=0)
    created_at  = Column(TIMESTAMP, server_default=func.now())
