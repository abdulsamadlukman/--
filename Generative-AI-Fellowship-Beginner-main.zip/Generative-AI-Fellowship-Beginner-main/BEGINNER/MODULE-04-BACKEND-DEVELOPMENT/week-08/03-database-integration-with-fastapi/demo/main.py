# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what main.py should look like at the END of this topic's demo.
# Requires MySQL running with the naija_backend database and products
# table populated (see week-08/02-mysql-setup-and-database-design/demo/schema.sql).
#
# Run with: uvicorn main:app --reload

from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from database import SessionLocal
from models import Product
from schemas import ProductOut

app = FastAPI()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/products", response_model=List[ProductOut])
def get_all_products(db: Session = Depends(get_db)):
    return db.query(Product).all()


@app.get("/products/{product_id}", response_model=ProductOut)
def get_product(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product
