# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what schemas.py should look like at the END of this topic's demo.

from pydantic import BaseModel
from typing import Optional


class ProductOut(BaseModel):
    id: int
    name: str
    price: float
    category: Optional[str] = None
    stock: int

    class Config:
        from_attributes = True
