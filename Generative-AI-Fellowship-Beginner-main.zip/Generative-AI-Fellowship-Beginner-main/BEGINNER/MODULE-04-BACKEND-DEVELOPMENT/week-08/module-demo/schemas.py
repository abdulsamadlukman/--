# Reference / checkpoint file — NOT a starter file to copy-paste from.

from pydantic import BaseModel
from typing import Optional


class UserCreate(BaseModel):
    name: str
    email: str
    password: str


class UserOut(BaseModel):
    id: int
    name: str
    email: str
    role: str

    class Config:
        from_attributes = True


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class JobCreate(BaseModel):
    title: str
    company: str
    location: str
    description: Optional[str] = None
    salary_range: Optional[str] = None


class JobOut(BaseModel):
    id: int
    title: str
    company: str
    location: str
    description: Optional[str] = None
    salary_range: Optional[str] = None
    is_active: bool
    posted_by: int

    class Config:
        from_attributes = True


class JobUpdate(BaseModel):
    title: Optional[str] = None
    company: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    salary_range: Optional[str] = None
    is_active: Optional[bool] = None
