# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what database.py should look like for the NaijaJobs project.
# Unlike the naija-backend project, this one reads DATABASE_URL from .env
# rather than hardcoding it — see .env.example.

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
