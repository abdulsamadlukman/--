# Reference / checkpoint file — NOT a starter file to copy-paste from.

from sqlalchemy import Column, Integer, String, Text, Boolean, TIMESTAMP, ForeignKey
from sqlalchemy.sql import func
from database import Base


class User(Base):
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(100), nullable=False)
    email         = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role          = Column(String(20), default="user")
    created_at    = Column(TIMESTAMP, server_default=func.now())


class Job(Base):
    __tablename__ = "jobs"

    id           = Column(Integer, primary_key=True, index=True)
    title        = Column(String(200), nullable=False)
    company      = Column(String(150), nullable=False)
    location     = Column(String(100), nullable=False)
    description  = Column(Text, nullable=True)
    salary_range = Column(String(100), nullable=True)
    is_active    = Column(Boolean, default=True)
    posted_by    = Column(Integer, ForeignKey("users.id"), nullable=False)
    created_at   = Column(TIMESTAMP, server_default=func.now())
