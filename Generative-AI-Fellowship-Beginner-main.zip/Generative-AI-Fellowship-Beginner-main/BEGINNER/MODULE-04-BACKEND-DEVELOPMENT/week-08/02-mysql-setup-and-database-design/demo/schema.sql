-- Reference / checkpoint file — NOT a script to run instead of typing the SQL live.
--
-- This is the naija_backend schema in its final state after this topic's
-- demo: the database, all 4 tables in dependency order, and just the 3
-- sample products Topic 3 depends on existing. It does not include the
-- demo user/order from Part 4 — those only existed to trigger the live
-- foreign-key violation demonstration, not as permanent seed data.
--
-- Use this to check your schema if something isn't matching, or to
-- rebuild the database from scratch if needed.

CREATE DATABASE IF NOT EXISTS naija_backend CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE naija_backend;

CREATE TABLE users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(20) DEFAULT 'user',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    description TEXT,
    price       DECIMAL(10, 2) NOT NULL,
    category    VARCHAR(100),
    stock       INT DEFAULT 0,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status       VARCHAR(20) DEFAULT 'pending',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    order_id    INT NOT NULL,
    product_id  INT NOT NULL,
    quantity    INT NOT NULL DEFAULT 1,
    unit_price  DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id)   REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Sample data — Topic 3 onward assumes these 3 products exist
INSERT INTO products (name, price, category, stock)
VALUES
    ('Indomie Noodles (Pack of 40)', 5500.00, 'food', 200),
    ('MTN 10GB Data Bundle', 3000.00, 'telecoms', 999),
    ('Dangote Cement 50kg', 7500.00, 'construction', 500);
