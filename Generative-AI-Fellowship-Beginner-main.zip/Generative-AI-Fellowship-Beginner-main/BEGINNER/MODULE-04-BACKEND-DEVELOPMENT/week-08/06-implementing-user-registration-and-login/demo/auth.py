# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# This is what auth.py should look like at the END of this topic's demo.
# JWT functions (create_access_token, get_current_user) are added in Topic 7.

import bcrypt


def hash_password(plain_password: str) -> str:
    hashed = bcrypt.hashpw(plain_password.encode(), bcrypt.gensalt())
    return hashed.decode()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(plain_password.encode(), hashed_password.encode())
