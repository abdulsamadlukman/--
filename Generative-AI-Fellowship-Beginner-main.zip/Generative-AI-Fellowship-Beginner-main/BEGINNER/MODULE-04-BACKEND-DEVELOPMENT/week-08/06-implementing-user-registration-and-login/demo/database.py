# Reference / checkpoint file — NOT a starter file to copy-paste from.
#
# Unchanged since Topic 3 — included here too so this folder is a
# complete, runnable checkpoint on its own. Replace "yourpassword" with
# your actual MySQL root password.

from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = "mysql+pymysql://root:yourpassword@localhost:3306/naija_backend"

engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()
