# Demo Guide - Overview of Popular LLMs (GPT, Claude, Gemini & LLaMA)
**Module 2, Topic 2 | Estimated duration: 25–30 minutes**
**Format: Live demo in a browser — no code, no notebook, no API key**

---

## What This Demo Teaches

- A direct, visible comparison of GPT, Claude, and Gemini's consumer apps on the same prompt
- How to talk about tone, style, and quality differences between models in plain terms
- The different ways people and companies access these models (web chat vs mobile app vs "a way for developers to plug this into their own product," which Topic 3 opens up)
- A practical framework for picking a model for a given Nigerian business use case

Like Topic 1, this stays entirely in consumer web apps. No API key or code is used here — that begins in Topic 3.

---

## Setup

1. Open three browser tabs: ChatGPT (chat.openai.com), Claude (claude.ai), and Gemini (gemini.google.com) — free accounts are enough for all three
2. Have your comparison prompt ready in a notes file so you can paste the same wording into all three quickly

---

## Demo Steps

### Part 1 - Same Prompt, Three Products (12 min)

Paste the exact same prompt into all three apps:

> "Write a short WhatsApp broadcast message announcing a Black Friday sale for a Lagos boutique. Keep it under 40 words."

Read all three outputs aloud, one after another.

> "Same instruction, three different companies' models, three different results. Notice the differences in tone — GPT tends to be direct, Claude often reads a little warmer and more polished, Gemini varies by prompt. None of these is 'wrong' — they're just different styles, the same way three different copywriters would each write it slightly differently."

Ask the class to vote: which version would they actually send to customers, and why?

### Part 2 - How People Actually Access These (8 min)

> "Right now we're using each company's own website — this is the 'web chat' access method, the same way most people use these tools day to day."

Point out the mobile app icon or app-store listing for at least one (e.g. the ChatGPT app).

> "There's also a mobile app version of most of these — same model, just a different front door."

Briefly show (without opening it) that each provider has a developer/API section in their site's footer or settings.

> "And there's a third way in — developers can plug these models directly into their own apps and products using something called an API. That's not magic, and it's not hard — it's exactly what we build, from scratch, next class in Topic 3."

### Part 3 - Choosing a Model for a Nigerian Use Case (7 min)

Present three quick scenarios and ask the class to pick a model family for each, using what they've seen plus the family traits from the slides (GPT: general-purpose and code; Claude: long documents and writing; Gemini: huge context and multimodal; LLaMA: privacy and self-hosting):

1. "A customer support chatbot for a Lagos fintech that needs to feel warm and trustworthy"
2. "A tool that summarises 200-page loan agreements for a bank's legal team"
3. "A hospital records assistant where patient data can never leave Nigerian servers"

Let students argue their picks before revealing the "typical" answer (Claude for warmth/writing, Claude or Gemini for long documents, LLaMA for data that can't leave your servers).

> "There's rarely one 'correct' answer — this is a judgment call you'll make often as an AI engineer, and it depends on the task, the budget, and how sensitive the data is."

---

## Discussion Prompt (3 min)

"If you were building a product for a Nigerian audience today, which of these four would you reach for first, and what would make you switch?"

---

## Common Student Misconceptions to Watch For

| Misconception | What to say |
|---|---|
| "One of these is just objectively the best" | "Each one leads in a different area — code, long documents, huge context, or running privately. 'Best' depends on the job." |
| "Using the website and using the API give different-quality answers" | "Same underlying model either way — the API is just a different door into it, one your own code can use." |
| "You need to be a big company to use these" | "Anyone can sign up for a free tier on most of these today — we'll get your own account working in Topic 3." |

---

## Up Next

Topic 3 - Accessing LLMs via API. This is where we stop clicking around in a browser and write our first Python code to talk to a model directly.
