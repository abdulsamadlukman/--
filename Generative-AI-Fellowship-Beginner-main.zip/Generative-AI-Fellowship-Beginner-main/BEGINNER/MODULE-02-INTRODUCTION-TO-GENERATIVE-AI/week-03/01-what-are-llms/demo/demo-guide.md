# Demo Guide - What are Large Language Models (LLMs)
**Module 2, Topic 1 | Estimated duration: 20–25 minutes**
**Format: Live demo in a browser — no code, no notebook, no API key**

---

## What This Demo Teaches

- What "predicting the next token" actually looks like in practice
- That an LLM's output is not deterministic — the same prompt can produce different wording each time
- A concrete feel for what LLMs are good at, and where they visibly struggle
- Sets up the "how do I actually build with this?" question that Topic 3 answers

This is a conceptual topic — the goal is intuition, not code. Topic 3 is where students write their first line of Python against an LLM; this demo deliberately stays in the browser so that first-code moment still feels new when it arrives.

---

## Setup

1. Open a browser with two tabs: ChatGPT (chat.openai.com) and Claude (claude.ai) — a free account on either is enough
2. No API key, no `.env` file, no installation — this is a live product demo, not a coding demo
3. Have a few draft prompts ready in a notes file so you're not typing live under pressure

---

## Demo Steps

### Part 1 - Watching Next-Token Prediction (7 min)

Open ChatGPT. Ask it directly to continue an unfinished message a Lagos shop owner might send a customer on WhatsApp — this is the realistic way people actually use it, and it still shows the model generating one token at a time:

> "Type this: 'Finish this WhatsApp message for me, don't ask any questions, just complete it: Good afternoon, thank you for your order. Your package will be ready for pick'"

Watch the reply appear on screen — point out that it's arriving word by word, not all at once.

> "Watch how the words appear one at a time as it types — that's not a typing animation for effect, that's literally the model predicting the single most likely next word, over and over, and showing you each one as it's produced. It isn't looking up an answer anywhere — that's the entire trick behind everything an LLM does."

Note for instructors: ChatGPT is a chat-tuned model, not a raw autocomplete box — if you just paste an unfinished sentence with no instruction, it may respond conversationally instead of continuing it. Always explicitly ask it to "finish/continue this" to get the completion behaviour this demo is illustrating.

### Part 2 - Same Prompt, Different Answer (5 min)

Ask the exact same question twice, back to back:

> "Suggest a name for a new Lagos-based food delivery startup."

Show that the two answers are worded differently.

> "Same words in, different words out — twice. A calculator gives you the same answer every time. An LLM doesn't, because it isn't retrieving a stored fact, it's generating a fresh, most-likely sequence of words each time you ask."

### Part 3 - Where It Shines vs Where It Stumbles (8 min)

Ask something it's genuinely strong at:

> "Write a polite WhatsApp reply to a customer asking if we deliver to Ikeja."

Show the fluent, useful reply.

> "That's a great result — this is squarely what LLMs are built for."

Now ask something it can't actually know:

> "What is today's exact USD to Naira exchange rate?"

Show that it gives an outdated, hedged, or made-up-sounding number.

> "Notice it still answers confidently, even though it has no way of knowing today's real rate. It was trained on text up to a certain date, and nothing since. This exact weakness — and others like it — is what all of Topic 5 is about. File it away for now."

---

## Discussion Prompt (5 min)

Ask the class: "Based on what you just saw, what's one task at your last job or in daily life you'd trust an LLM with — and one you wouldn't?"

Use the answers to reinforce: LLMs generate plausible language, they don't look things up or guarantee accuracy.

---

## Common Student Misconceptions to Watch For

| Misconception | What to say |
|---|---|
| "It searched the internet for that answer" | "No live browsing here — it's producing the most statistically likely next words based on its training." |
| "It got the exchange rate wrong, so it's broken" | "It's not broken — it simply has no way to know a number from after its training cutoff. That's a real limitation, not a bug, and we'll cover exactly how to work around it in Topic 5." |
| "It will give the exact same answer every time" | "It won't, by design — that's the randomness in how it selects among likely next words." |

---

## Up Next

Topic 2 - Overview of Popular LLMs. We compare GPT, Claude, Gemini, and LLaMA side by side on the same prompt, still without writing any code.
