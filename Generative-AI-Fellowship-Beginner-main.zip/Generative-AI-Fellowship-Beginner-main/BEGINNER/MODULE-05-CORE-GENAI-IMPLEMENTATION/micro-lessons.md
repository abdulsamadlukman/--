# Module 5 - Core GenAI Implementation: Micro Lessons
> For use with AI practice question generation. Beginner level only.

---

## Week 9, Topic 1: The Attention Mechanism

**Title:** The Attention Mechanism

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will implement scaled dot-product attention from scratch in pure NumPy, understanding the Query/Key/Value lookup analogy and the four-step Score → Scale → Normalise → Blend process.

**Description for AI:**
This topic teaches the foundational attention mechanism that underlies every Transformer model. Students learn that older sequence models (RNNs, LSTMs) compressed a whole sentence into one fixed-size hidden state, losing information over long sentences, and that attention fixes this by letting every word look directly at every other word. The core intuition is a lookup system: a Query asks "what am I looking for," a Key offers "what do I have," and a Value delivers "what do I actually contribute" — with every word playing all three roles simultaneously via three separate learned projections of the same embedding. Students implement the four-step process by hand in NumPy: Score (Q·K dot product), Scale (divide by √d_k to keep softmax stable), Normalise (softmax into attention weights summing to 1), and Blend (weighted combination of Value vectors). The running example is an English-to-Yoruba sentence pair ("I am going to the market" / "Mo n lọ si ọja"), reinforced by a tiny two-token hand-traceable worked example (Query=(2,0), Keys=(2,0)/(0,2)) that students verify their code against numerically. The AI-use mode for this week is Manual + Tutor — students write the code themselves; AI helps explain concepts and debug, not generate the implementation.

**Common Mistakes:**
- Forgetting to scale scores by √d_k before softmax, causing numerically unstable or overconfident attention weights
- Confusing which matrix (Q, K, or V) plays which role in the lookup analogy
- Applying softmax across the wrong axis when moving from a single Query to a full sentence (row-wise vs. column-wise)
- Assuming self-attention and cross-attention are different mechanisms rather than the same math with different Q/K/V sources
- Expecting exact percentages to match a slide's illustrative example when using different random embeddings — the mechanism matters, not matching someone else's specific numbers

---

## Week 9, Topic 2: Multi-Head Attention & Positional Encoding

**Title:** Multi-Head Attention & Positional Encoding

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will extend single-head attention into multi-head attention by splitting Q/K/V into slices, and implement sinusoidal positional encoding from scratch to give the model a sense of word order.

**Description for AI:**
This topic addresses two limitations of the single attention mechanism from Topic 1. First, one attention head can only capture one kind of relationship at a time (e.g. grammar, nearby-word context, long-range reference), so multi-head attention runs the same scaled dot-product attention several times in parallel on smaller slices of the embedding, then concatenates and projects the results back together — Split, Attend, Concatenate, Project. Second, because Transformers process all words in parallel (unlike RNNs), they have no built-in sense of word order; the topic demonstrates this with Yoruba/Hausa word-order examples where reordering the same words flips the meaning entirely. The fix is positional encoding: a fixed sine/cosine pattern (PE(pos,2i)=sin(pos/10000^(2i/d)), PE(pos,2i+1)=cos(...)) added element-by-element to each token's embedding before Q/K/V are computed, giving every position a unique "fingerprint." Students implement both mechanisms in NumPy, reusing Topic 1's attention function unchanged inside each head, and verify that adding positional encoding measurably changes the attention output even for the same word content.

**Common Mistakes:**
- Splitting Q/K/V into heads incorrectly (e.g. splitting before projection instead of after, or with mismatched dimensions)
- Believing num_heads must divide d_model in a special way beyond simple even division
- Implementing the positional encoding formula with the wrong dimension pairing (mixing up which sine and cosine share the same frequency)
- Assuming positional encoding is learned like Q/K/V weights, when it is actually a fixed, non-trained mathematical formula in the original Transformer design
- Not realising that even an early-position word's output changes when positional encoding is added, because attention blends in every other (now position-aware) word's Value too

---

## Week 9, Topic 3: Encoder & Decoder Architecture

**Title:** Encoder & Decoder Architecture

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will understand the overall encoder-decoder Transformer architecture conceptually — mapping every architectural piece back to code already built in Topics 1, 2, and 4 — including masked self-attention and cross-attention.

**Description for AI:**
This is a non-coding, diagrammatic topic that connects the pieces built hands-on elsewhere in the week into the full Transformer architecture. Students learn that an encoder layer is exactly the transformer_block() built in Topic 4 (multi-head self-attention + feed-forward, each wrapped in residual connections and layer normalisation), stacked N times. The decoder adds one new idea on top of the same building blocks: masked self-attention, where positions representing "the future" have their score forced to negative infinity before softmax, so the decoder cannot peek at tokens it hasn't generated yet during training — illustrated with a Yoruba translation example showing exactly which words a given decoding step can and cannot attend to. Cross-attention is introduced as the same attention mechanism with a twist: Query comes from the decoder, but Key and Value come from the encoder's final output, which is how the decoder "reads" the source sentence while generating the translation. The topic deliberately introduces no new code — its purpose is recognition, not implementation.

**Common Mistakes:**
- Believing the decoder requires an entirely different attention mechanism rather than the same function with a masking addition and a different Key/Value source
- Using zero instead of negative infinity to mask future positions before softmax, which breaks the property that each row's weights still sum to 1
- Confusing self-attention (Query, Key, Value all from the same sequence) with cross-attention (Query from the decoder, Key/Value from the encoder)
- Assuming the encoder also needs masking, when only the decoder needs it since the encoder reads the entire input sentence at once
- Thinking this topic requires new code to "pass," when its explicit goal is recognising already-built code in a new architectural context

---

## Week 9, Topic 4: Implementing a Simplified Transformer Block

**Title:** Implementing a Simplified Transformer Block

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will assemble a complete Transformer block from scratch in NumPy — multi-head attention, a feed-forward network, residual connections, and layer normalisation — and stack multiple blocks into a deeper encoder.

**Description for AI:**
This topic brings together every piece built earlier in the week into one complete, working unit. Students implement a feed-forward network (two linear layers with a ReLU in between, all via NumPy matrix multiplication) and a simplified layer normalisation function (rescaling each token's values to roughly mean 0, standard deviation 1). These combine with Topic 2's multi_head_attention() inside a full transformer_block(): multi-head attention wrapped in a residual connection and layer norm, followed by the feed-forward network wrapped in its own residual connection and layer norm. Students then stack two independent blocks and run the full English-Yoruba running example through the complete pipeline, inspecting how much each word's representation changed end-to-end from its starting embedding — a concrete, numeric confirmation that meaning, word order, and gathered context have all been folded into the final output vectors.

**Common Mistakes:**
- Applying the residual connection incorrectly — adding the input to the wrong sublayer's output, or applying layer norm before instead of after the addition
- Forgetting that layer normalisation is applied twice per block (once after attention, once after the feed-forward network), not once
- Implementing the feed-forward network without the ReLU non-linearity between the two linear layers, effectively collapsing it into a single linear transformation
- Assuming stacking blocks means reusing the exact same weights for every block, rather than each block having its own independent parameters
- Not verifying the sanity checks (layer norm mean ≈ 0, std ≈ 1) before trusting the rest of the pipeline's output

---

## Week 10, Topic 1: What are Embeddings & How They Work

**Title:** What are Embeddings & How They Work

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will understand what embeddings are, why raw text cannot be compared directly, and the intuition of meaning as distance and direction in vector space.

**Description for AI:**
This non-coding, conceptual topic introduces embeddings before any implementation begins. Students learn that an embedding is a fixed-length vector of numbers representing a word, sentence, or document, such that similar meanings produce vectors that sit close together in space — using a Nigerian-flavoured running example (danfo, bus, and okada clustering together as "transport," while jollof rice and suya cluster separately as "food"). The topic also covers vector arithmetic capturing relationships, not just closeness (the classic king - man + woman ≈ queen example, alongside a Nigerian-flavoured Lagos - Nigeria + Ghana ≈ Accra capital-city relationship), and explains that real embeddings have hundreds of dimensions, visualised via dimensionality-reduction techniques like PCA or t-SNE. The topic closes honestly on real limitations: static embeddings can't distinguish a word's different meanings by context (e.g. "bank"), embeddings inherit biases from their training data, and embedding quality for Nigerian languages like Pidgin, Yoruba, Igbo, and Hausa is often weaker due to less available training data.

**Common Mistakes:**
- Assuming embeddings are compared by looking at raw text similarity (shared letters) rather than by the vector's position in space
- Believing embedding vectors must be human-readable or interpretable dimension by dimension
- Thinking vector arithmetic like "king - man + woman ≈ queen" is guaranteed to work perfectly every time, rather than being an emergent property of well-trained embedding spaces
- Assuming embeddings are bias-free simply because they're "just math," rather than understanding they reflect whatever patterns exist in their training data
- Confusing word-level, sentence-level, and document-level embeddings as fundamentally different techniques rather than the same underlying idea applied at different granularities

---

## Week 10, Topic 2: Implementing a Basic Word Embedding Model (Word2Vec)

**Title:** Implementing a Basic Word Embedding Model (Word2Vec)

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will train a small Word2Vec model from scratch using gensim on a Nigerian-English corpus, and inspect what it learned via nearest-neighbour queries and vector arithmetic.

**Description for AI:**
This topic teaches how embeddings are actually trained, using Word2Vec as the entry point. Students learn the distributional hypothesis — a model learns word meaning purely from which words appear near each other in real text, never from a dictionary — and the CBOW vs. skip-gram framing (predicting a word from context vs. predicting context from a word). Using gensim, students train a skip-gram model on a 32-sentence Nigerian-English corpus (market/trader/price, danfo/bus/okada, jollof/suya/moin-moin, naira/transfer clusters), inspect a trained word's raw vector, and use most_similar() to find nearest neighbours — expecting "market" to surface "trader" and "price," and "danfo" to surface "bus" and "okada." Students also measure direct similarity between specific word pairs, attempt simple vector arithmetic, and deliberately trigger the out-of-vocabulary limitation by requesting a vector for a word never seen in training (e.g. "airplane"), which raises a KeyError — a genuine, well-known Word2Vec limitation, not a bug.

**Common Mistakes:**
- Expecting clean, textbook-quality nearest-neighbour results from a tiny 32-sentence corpus, rather than understanding that corpus size directly limits embedding quality
- Confusing sg=1 (skip-gram) and sg=0 (CBOW) parameter values
- Not setting a random seed, making results non-reproducible and harder to discuss as a group
- Assuming a trained Word2Vec model can produce a vector for any word typed in, rather than understanding the out-of-vocabulary limitation
- Believing vector arithmetic on a tiny custom-trained model should produce results as clean as the famous large-scale king/queen example

---

## Week 10, Topic 3: Vector Similarity Search

**Title:** Vector Similarity Search

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will implement cosine similarity and Euclidean distance from scratch, build a brute-force nearest-neighbour search over Nigerian fintech support queries, and measure how search time grows with data size.

**Description for AI:**
This topic formalises "how similar are two vectors" into precise, computable metrics. Students implement cosine similarity (measuring only the angle between vectors, ignoring magnitude) and Euclidean distance (straight-line distance, sensitive to magnitude) by hand in NumPy, confirming on toy vectors that two vectors pointing the same direction score 1.0 on cosine similarity even if their lengths differ, while Euclidean distance between them is nonzero. Students then train word vectors on a set of Nigerian fintech customer-support queries (PIN reset, failed transfer, balance check, etc.), average word vectors into sentence vectors, and implement brute-force nearest-neighbour search from scratch — comparing a new query against every stored vector, sorting by score. A key discovery is that cosine and Euclidean rankings can genuinely disagree on the same data, because averaged sentence vectors carry magnitude noise that Euclidean distance is sensitive to but cosine similarity ignores. Finally, students time the brute-force search loop as simulated dataset size grows from 16 to 100,000 documents, observing the linear growth that motivates vector databases in the next topic.

**Common Mistakes:**
- Assuming cosine similarity and Euclidean distance will always agree on which result is "closest"
- Forgetting that averaging word vectors gives common connecting words ("the," "is," "you") outsized influence on the resulting sentence vector, compressing similarity scores together
- Believing brute-force search is always the wrong choice, rather than understanding it is the correct, simplest choice at small scale
- Expecting the exact timing numbers from a slide or another student's machine to match their own — absolute wall-clock timing is hardware-dependent, only the growth pattern is the real lesson
- Confusing "smaller is better" (distance) with "bigger is better" (similarity) when sorting results

---

## Week 10, Topic 4: Introduction to Vector Databases (ChromaDB, FAISS, pgvector, Pinecone)

**Title:** Introduction to Vector Databases (ChromaDB, FAISS, pgvector, Pinecone)

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will store and query embedded documents in a local ChromaDB collection, compare the same query against a FAISS index, and understand conceptually how pgvector and Pinecone would handle the same task.

**Description for AI:**
This topic introduces purpose-built vector databases as the solution to brute-force search's scaling problem measured in Topic 3. Students learn that a vector database adds indexing (organising vectors so most can be skipped at search time, enabling approximate nearest-neighbour search), persistence to disk, and metadata storage/filtering — capabilities a plain Python list lacks. Hands-on, students set up a local ChromaDB collection configured for cosine distance (since Topic 3 showed cosine handles averaged-vector magnitude noise better than Euclidean), insert embedded fintech support queries with category metadata, and query it — then build the same vectors into a FAISS index using IndexFlatIP with normalised vectors (mathematically equivalent to cosine similarity), confirming both tools return the same top results once the metric is fixed. Students also read (without running) conceptual pgvector SQL and Pinecone Python code stubs, understanding pgvector's advantage of living inside an existing PostgreSQL database and Pinecone's advantage of being a fully managed, zero-infrastructure cloud service. A Nigerian-context discussion covers connectivity/latency, NDPA 2023 data-residency considerations, and cost trade-offs between self-hosted and foreign-cloud options.

**Common Mistakes:**
- Assuming a vector database always uses the same default distance metric as a from-scratch cosine similarity implementation, when many default to Euclidean or another metric unless explicitly configured
- Believing FAISS is a full database like ChromaDB, rather than understanding it is a search library that doesn't handle metadata or persistence on its own
- Forgetting to normalise vectors before using FAISS's IndexFlatIP if relying on the inner-product-equals-cosine-similarity equivalence
- Assuming approximate nearest-neighbour search is always wrong when it doesn't return the mathematically perfect top result, rather than understanding the intentional speed-for-accuracy trade-off
- Treating "which vector database is best" as having one universal answer, rather than depending on scale, existing infrastructure, budget, and operational needs

---

## Week 10, Topic 5: Building a Simple Semantic Search Engine

**Title:** Building a Simple Semantic Search Engine

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will assemble a complete semantic search pipeline for a Lagos fashion store's FAQ set, and prove it beats naive keyword search on a real customer question sharing zero exact words with the correct answer.

**Description for AI:**
This is the week's capstone demo, wiring together every technique built in Topics 1-4 into one working system. Students load 20 FAQ entries for a Lagos-based online fashion store (delivery, returns, sizing, payment), then train Word2Vec not just on the FAQs but on an additional set of background sentences using everyday phrasing — solving the real problem that 20 FAQs alone are too narrow a corpus to teach the model that "pay" relates to "transfer" or "package" relates to "delivered." Students also apply stopword filtering before averaging word vectors into sentence vectors, directly fixing a limitation identified in Topic 3 (common words dominating short averaged vectors). The embedded FAQs are stored in a cosine-distance ChromaDB collection, and the payoff moment is querying "can i pay with my phone" — a question sharing zero exact words with any FAQ — and watching semantic search correctly surface the payment FAQ while a from-scratch keyword search (built in the same notebook) returns nothing useful, with every FAQ tied at zero word overlap. Students then compare keyword vs. semantic search's respective strengths (exact product codes vs. rephrased questions) and see how this pipeline is explicitly the retrieval half of next week's RAG systems.

**Common Mistakes:**
- Training embeddings only on the small FAQ set without adding broader background sentences, producing a model too narrow to generalise to real customer phrasing
- Forgetting to filter out stopwords before averaging, which re-introduces the magnitude-noise problem from Topic 3
- Assuming semantic search is a strict upgrade over keyword search in every case, rather than understanding each has genuine strengths (e.g. keyword search wins on exact product codes and typos)
- Storing the background training sentences as searchable documents by mistake, when they should only shape the embedding model, never appear as a customer-facing search result
- Not verifying the "zero keyword overlap" claim is actually true for a chosen test question before presenting it as the payoff example

---

## Week 11, Topic 1: What is RAG & Why it Matters

**Title:** What is RAG & Why it Matters

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will observe an LLM fail to answer a question outside its training data (via refusal or hallucination), then fix it by manually supplying the relevant document as context — the foundational idea behind RAG.

**Description for AI:**
This topic introduces Retrieval-Augmented Generation by first demonstrating the problem it solves. Students learn that every LLM has a knowledge cutoff and no access to private information, leading to either honest refusal or confident hallucination when asked something outside its training data. Using a fictional Nigerian bank, Naija One Bank, and its Flexi Save savings account policy, students first ask an LLM a specific policy question cold (with no context) and observe the failure, then paste the actual policy document into the prompt before asking the same question again — watching the answer become correct, grounded, and traceable. The core insight is that nothing about the model changed between the two calls; only what it was shown before answering changed. Students also learn RAG's positioning relative to fine-tuning (RAG is faster/cheaper for fast-changing or private data) and relative to "just paste everything into the prompt" (retrieval solves cost, context-window limits, accuracy, and speed all at once). The topic closes honestly: RAG reduces hallucination but doesn't eliminate it, since bad chunking, bad retrieval, or careless prompting can all still cause failures — the problems the rest of the module solves one at a time.

**Common Mistakes:**
- Assuming an LLM will always hallucinate rather than refuse when asked something it cannot know — both outcomes are valid and prove the same underlying point
- Believing clever prompt wording alone can make a model answer correctly about information genuinely absent from its training data
- Confusing RAG with fine-tuning, or assuming one always replaces the other rather than being complementary techniques for different needs
- Thinking a large context window makes retrieval unnecessary, ignoring the cost, accuracy, and speed costs of stuffing a prompt with irrelevant text
- Believing RAG guarantees a hallucination-free system, rather than understanding it shifts the hard problem to "did we retrieve and present the right information?"

---

## Week 11, Topic 2: Document Loading & Chunking Strategies

**Title:** Document Loading & Chunking Strategies

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will implement and compare fixed-size chunking, chunking with overlap, and sentence-aware chunking, verifying by hand which strategy keeps a specific fact intact across chunk boundaries.

**Description for AI:**
This topic covers preparing documents for retrieval — the first two steps of the RAG pipeline. Students learn that loading means extracting clean plain text from a source file (PDF, Word, web page), and that a whole document is too large and unfocused to retrieve directly, motivating chunking into smaller, searchable pieces. Using the Naija One Bank policy document, students implement naive fixed-size chunking (cutting every N characters regardless of what's there), chunking with overlap (each new chunk repeating the end of the previous one as a safety net), and sentence-aware chunking (splitting at sentence boundaries first, then grouping up to a target size). The chunk_size (140) and overlap (40) values are deliberately tuned so that fixed-size chunking visibly splits the sentence containing "4.2% per annum" across a chunk boundary, while both overlap chunking and sentence-aware chunking keep it whole — a concrete, checkable proof rather than an assertion. Students also learn the general trade-off between chunks too small (losing context) and too large (diluting relevance), and that the right chunk size depends on document type.

**Common Mistakes:**
- Chunking before cleaning the source text, letting headers, footers, or page numbers pollute every chunk
- Using no overlap at all with fixed-size chunking, leaving no safety net for facts stranded at a chunk boundary
- Applying the same chunk size setting to both a one-line FAQ and a 50-page contract, rather than matching chunk size to document type
- Assuming a simple sentence-splitting regex handles every edge case (like abbreviations or decimals) as robustly as a production NLP tokenizer
- Believing chunking problems are always visible immediately, when in reality they only show up later as bad or missing retrieval results

---

## Week 11, Topic 3: Building a Custom Retriever

**Title:** Building a Custom Retriever

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will build a complete retriever from scratch — embedding chunks and queries, scoring via cosine similarity, and returning the top-k most relevant chunks — and package it into one reusable retrieve() function.

**Description for AI:**
This topic builds the retrieval half of RAG from first principles. Students learn why keyword matching fails for retrieval (a question like "how much can I take out... before I get charged" shares no exact words with the chunk that answers it, "3 free withdrawals... NGN 500 fee"), motivating embeddings as the fix. Students embed each of the Naija One Bank policy chunks once, store them alongside their text, then embed an incoming question on the spot and score it against every stored chunk using cosine similarity, before ranking and returning the top-k. This is packaged into a single retrieve() function reused unchanged in every subsequent topic this week. The topic also covers real limitations of this from-scratch, in-memory approach — it gets slower as the number of chunks grows, and nothing persists once the program stops — motivating both the vector database (Topic 4's LangChain equivalent) and production vector databases from Week 10. Note: this fellowship's demos use OpenAI's embedding API (via a separate key from the chat provider, since not every gateway serves both), rather than any single-vendor-locked embedding service.

**Common Mistakes:**
- Believing a chunk must share words with a question to be retrieved correctly, rather than trusting semantic (meaning-based) matching
- Embedding chunks fresh on every single query instead of once, when the knowledge base is first built
- Forgetting that different embedding providers/models are not interchangeable — vectors from two different models don't live in the same comparable space
- Assuming retrieval will always rank the "obviously correct" chunk first, rather than treating retrieval quality as something to actually check, not assume
- Mixing up which embedding client is being used for which purpose when a project uses two different API keys (one for chat, one for embeddings)

---

## Week 11, Topic 4: Introduction to LangChain as an Orchestration Framework

**Title:** Introduction to LangChain as an Orchestration Framework

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will rebuild the same retrieval pipeline from Topic 3 using LangChain's text splitter, embeddings integration, and vector store abstractions, and compare the results directly against the from-scratch version.

**Description for AI:**
This topic introduces orchestration frameworks as ready-made, tested building blocks for common AI pipeline pieces, using the construction-site analogy of building with standard lumber and nails versus forging your own. Students learn LangChain is the most widely used framework for LLM applications, with document loaders, text splitters, and retriever/vector-store abstractions each mapping directly onto something already hand-built earlier in the week: RecursiveCharacterTextSplitter replaces the custom sentence-aware chunking function, and FAISS.from_texts() plus .as_retriever() replaces the entire embed-store-compare-rank retrieve() function in about five lines. Hands-on, students rebuild the same Naija One Bank retrieval pipeline with LangChain and confirm it surfaces the same top-ranked chunk as the from-scratch version for the same question — proof the two implementations understand the same underlying idea, not just similar-looking code. The topic closes with an honest framing of when to hand-roll versus when to use a framework: hand-rolling is valuable for learning or very small projects, while frameworks pay off as a project's scope, provider needs, and document variety grow.

**Common Mistakes:**
- Assuming LangChain's text splitter will produce byte-identical chunk boundaries to a hand-written sentence splitter, rather than understanding both are reasonable, different implementations of the same idea
- Forgetting that a class like LangChain's embeddings integration may default to looking for a generic environment variable (e.g. a plain API key name) that doesn't match this project's actual credential setup, requiring an explicit override
- Believing FAISS (used via LangChain here) automatically persists data to disk, when the default in-memory behaviour has the same limitation as the from-scratch version
- Treating "which version is better, from-scratch or LangChain" as having one correct answer, rather than a trade-off depending on project stage and goals
- Assuming a framework removes the need to understand what's happening underneath, rather than making prior hands-on understanding what makes the framework's shortcuts trustworthy

---

## Week 11, Topic 5: Integrating the Retriever with an LLM

**Title:** Integrating the Retriever with an LLM

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will connect the Topic 3 retriever to an LLM call, add a relevance-threshold check to refuse out-of-scope questions, and package the full flow into one answer_question() function.

**Description for AI:**
This topic connects the two working halves built separately earlier in the module — a retriever (Topic 3) and an LLM call (Topic 1) — into one complete RAG pipeline. Students build a build_prompt() function assembling retrieved chunks and the question into a three-part prompt (instruction, context, question), and implement a relevance threshold (a minimum cosine similarity score) that decides whether to call the LLM at all, returning an honest fallback message instead when the top retrieved chunk isn't actually relevant — catching a subtler form of hallucination where the model would otherwise try its best with irrelevant context. Students test the complete answer_question() pipeline on both a question the knowledge base can answer (confirming an accurate, grounded response) and one it cannot ("interest rate on a car loan," when only savings account policy exists), confirming the system says so honestly rather than inventing an answer. A key technical point: the specific relevance-threshold value must be tuned against the actual embedding model in use, since different models produce different baseline similarity ranges — a value that works for one provider doesn't automatically transfer to another.

**Common Mistakes:**
- Assuming a fixed relevance-threshold number (e.g. 0.4) is a universal constant rather than something that must be verified against the actual embedding model's real score distribution
- Confusing "the LLM decided not to answer" (a model's own choice, as seen in Topic 1) with "the system decided not to call the LLM at all" (a deliberate design decision made before the model ever sees the question)
- Believing retrieve() returns fewer results when nothing is relevant, rather than understanding it always returns k results regardless of quality — it's the score, not the count, that should trigger the fallback
- Skipping the threshold check under the assumption that a well-written prompt instruction alone reliably prevents hallucination on out-of-scope questions
- Treating a system that says "I don't know" as a failure, rather than recognising it as the intended, more trustworthy behaviour

---

## Week 11, Topic 6: Prompt Construction for RAG

**Title:** Prompt Construction for RAG

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will sharpen a working RAG prompt by numbering retrieved sources and adding a citation instruction, comparing the resulting answer's traceability against the unlabelled Topic 5 version.

**Description for AI:**
This topic addresses a subtlety often missed by beginners: good retrieval does not guarantee a good answer, since a poorly worded prompt can still cause a model to ignore context, blend it with outside knowledge, or answer confidently despite insufficient information. Students take Topic 5's working build_prompt_v1() and build an improved version that numbers each retrieved chunk as a labelled source and explicitly instructs the model to state which source number(s) it used after answering. Running the exact same question through both prompt versions demonstrates the real difference isn't correctness (both usually get the content right) but traceability — version 2 produces a verifiable Source: N line a human or auditor can check against the actual document, which matters enormously for Nigerian financial and legal RAG products where audibility and debugging depend on knowing exactly which document supported a claim. Students also test the out-of-scope question from Topic 5 through the improved prompt, observing that a strong instruction alone is a weaker defence than the score-threshold check — the two are complementary, not redundant.

**Common Mistakes:**
- Requesting citations without numbering or clearly labelling the source chunks first, leaving the model nothing concrete to cite back to
- Assuming a citation instruction alone fully solves the hallucination problem, rather than understanding it's a second layer of defence alongside the relevance threshold
- Treating Version 1's correct-but-uncited answer as "wrong," when the actual teaching point is traceability, not correctness
- Forgetting that changing prompt wording is itself a change that should be tested against real questions, not assumed to work simply because it reads better to a human
- Not verifying that the model actually followed the citation instruction correctly (citing the right source number) rather than assuming any Source: N line is automatically correct

---

## Week 11, Topic 7: RAG Evaluation & Use Cases

**Title:** RAG Evaluation & Use Cases

**Programming Language:** Python

**Coding Exercise:** Yes

**Learning Objective:**
Students will build a small labelled test set to measure retrieval quality, manually check answer faithfulness against cited sources, and diagnose a deliberately tricky, genuinely uncertain edge-case question.

**Description for AI:**
This closing topic teaches how to evaluate a RAG system properly, rather than only spot-checking a couple of questions by eye. Students learn RAG has two separately evaluable stages — retrieval quality (did the right chunk get found?) and generation quality/faithfulness (is every claim in the answer actually supported by that chunk?) — and that separating them matters because the correct fix for a wrong answer depends entirely on which stage failed. Students build a labelled test set of Naija One Bank questions with known correct chunk indices, measure what fraction the retriever actually finds, then manually check faithfulness by reading a generated answer directly against its cited source chunk. The centrepiece exercise is a deliberately tricky, genuinely open-ended question ("Can I open a Flexi Save account for my small business?") that sits in a grey area the document never directly addresses — students run it live, observe whatever the system actually does, and diagnose it using a structured failure-mode table (retrieval failure, generation/faithfulness failure, or working-as-intended) rather than being told the "correct" outcome in advance. The topic closes by surveying real-world RAG use cases across Nigerian banking, legal, healthcare, government, and e-commerce sectors, and the three conditions where RAG adds the most value: a controllable source, source material that changes over time, and high stakes for accuracy.

**Common Mistakes:**
- Treating a 4-out-of-4 retrieval score on a handful of hand-picked questions as proof a system is production-ready, rather than a basic sanity check
- Expecting the tricky edge-case question to always produce the same result, when LLM output isn't perfectly deterministic — especially on genuinely borderline questions
- Confusing a retrieval failure (the right chunk was never found) with a generation/faithfulness failure (the right chunk was found, but the model still answered incorrectly or overconfidently)
- Assuming faithfulness checking means judging whether an answer "sounds right," rather than verifying every specific claim against the actual cited source text
- Believing evaluation is a one-time task completed before launch, rather than something that must be re-run whenever documents, chunking, prompts, or the underlying models change
