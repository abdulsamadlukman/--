# Module 5, Week 10 - Module Demo Guide
## Embeddings & Vector DBs from Scratch — The NaijaThreads Story

**Notebook:** `module-demo/notebook.ipynb`
**Audience:** Whole cohort — this is the week's closing, synthesising session
**Estimated live-coding time:** 30–35 minutes

---

## Purpose of This Session

This is **not** a sixth new topic — it's the same techniques from Topics 1–5, retold as one continuous story, so fellows leave the week seeing the whole shape of the pipeline rather than five separate exercises. Frame it that way in your opening line: *"Nothing in today's notebook is new. Every function, every idea, you've already written this week. Today we watch it become one thing."*

Run this live, start to finish, without interruption for Q&A until the end of each Part — the narrative momentum is the point.

---

## Opening (2 minutes)

Introduce NaijaThreads before touching any code: *"NaijaThreads is a small Lagos fashion store. Right now, their FAQ search box only finds an answer if a customer types the exact words on the page. That's costing them sales from confused customers who ask reasonable questions in their own words. By the end of this notebook, we'll have fixed that — completely from scratch."*

Walk through the 4-part roadmap in the intro cell before running anything, so fellows know where the story is going.

---

## Part 1 — Turning Words Into Vectors (≈8 minutes)

Say: *"First, NaijaThreads' 20 FAQs — their entire searchable knowledge, right now just text."*

Run the FAQ-loading cell, then introduce the background corpus: *"Same move as Topic 5 — 20 FAQs alone can't teach a model that 'pay' relates to 'transfer.' We add background sentences purely for training, and they'll never show up as search results."*

Run training. Then run the nearest-neighbour check on `"arrive"` and read the result aloud: *"'package' comes out as the single closest word — and that connection only exists because of the background sentences we added. This is Topic 2's whole lesson, now working on NaijaThreads' actual content."* If a less-obvious word shows up further down the list, name it as the familiar "small corpus" noise from Topics 2–3, not a problem.

---

## Part 2 — Measuring Similarity, By Hand (≈6 minutes)

Say: *"Before any tool searches for us, let's prove we know exactly what 'similar' means — the same formulas from Topic 3, applied to NaijaThreads' real FAQs this time."*

Run the cosine/Euclidean cell. Read the four numbers aloud and connect them to real categories: *"Delivery and returns score more similar to each other than delivery and payment do — on both metrics. That's not a coincidence; delivery and returns questions genuinely share more vocabulary (`days`, `delivery`, `item`) than delivery and payment do."*

Close this section with the throughline: *"This is the exact math running underneath every vector database — nothing from here forward is a black box."*

---

## Part 3 — From Brute Force to a Vector Database (≈8 minutes)

Say: *"Searching 20 FAQs by hand is instant. Let's prove that — and then prove why NaijaThreads can't lean on this forever."*

Run the timing cell. Read the numbers as they print, landing on the last one: *"Half a second at 100,000 documents. NaijaThreads isn't there yet — but if this pipeline works today, the business might be, someday. This is exactly why we reach for a real vector database now, before it's a problem."*

Set up and populate ChromaDB. Run the quick sanity-check query (`"how can i pay"`) and confirm the payment FAQ comes back on top before moving to Part 4: *"Pipeline's wired up correctly — now let's actually put it to the test."*

---

## Part 4 — Assembling the Full Search Engine (≈8 minutes)

This is the climax — slow all the way down here.

Say: *"Here's a real customer question: 'can i pay with my phone.' Watch two searches run against it — NaijaThreads' current keyword search, and our new semantic search."*

Run the comparison cell. Read the keyword results first: *"Every single FAQ ties at zero. NaijaThreads' current search has nothing to offer this customer."* Then read the semantic results: *"Distance 0.250, the payment FAQ, clearly on top — despite sharing zero words with the question."*

Let the bolded takeaway line in the notebook land: *"This is the whole week, in one result."*

---

## Closing (≈3 minutes)

Walk through the summary table, tying each row explicitly back to the week's topics fellows already sat through. Then read the final paragraph aloud and bridge to Week 11: *"NaijaThreads now has real semantic search — but a customer still has to read the matched FAQ and figure out the answer themselves. Next week, we hand this same retrieved result to an LLM, and instead of 'here's a paragraph that might help,' NaijaThreads' assistant says the answer directly, in plain language. That's RAG — and we've already built its retrieval half."*

---

## Common Fellow Questions & Suggested Answers

**"Why does this notebook use a fresh 'NaijaThreads' framing instead of just replaying Topic 5's notebook?"**
Good question to invite, and worth answering honestly: it's the same underlying FAQ set and search engine as Topic 5, but restructured as one uninterrupted story spanning Topics 1 through 5, instead of five separate standalone demos. The goal today is synthesis, not new content.

**"Is 100,000 documents realistic for a small business like NaijaThreads?"**
Not today — but the point isn't "NaijaThreads needs this now," it's "this is the exact moment your search approach needs to change if you're ever successful enough to need it." Building the vector database habit early costs almost nothing and avoids a painful rewrite later.

**"Could we have skipped ChromaDB and just kept using our own Python search from Topic 3?"**
At 20 documents, absolutely — brute force would work fine forever at this specific scale. We used ChromaDB here to complete the pipeline the way a real, growing business would build it, and because it gives us metadata and persistence for free.

---

## Timing Guide

| Section | Time |
|---|---|
| Opening / framing | 2 min |
| Part 1 — Words to vectors | 8 min |
| Part 2 — Similarity by hand | 6 min |
| Part 3 — Brute force → vector database | 8 min |
| Part 4 — Full search engine + comparison | 8 min |
| Closing + bridge to Week 11 | 3 min |

---

*Module 5, Week 10 Module Demo - Foundational AI*
