# Module 6 - Project & Responsible AI: Micro Lessons
> For use with AI practice question generation. Beginner level only.

---

## Topic 1: Ethical AI - Bias, Fairness & Responsible Use

**Title:** Ethical AI - Bias, Fairness & Responsible Use

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will recognise where bias enters AI systems at every stage of the pipeline, understand multiple practical definitions of fairness and why they can conflict, and apply a ten-point checklist for building AI more responsibly — using Nigerian examples such as a loan-scoring model that underrepresents informal-sector income earners.

**Description for AI:**
This topic introduces bias and fairness in AI systems conceptually, through discussion and case studies rather than code. Students learn that bias can enter a pipeline at five stages — data collection, labelling, feature selection, model training, and deployment context — and that a model can be mathematically correct while still being socially unfair. The central Nigerian case study contrasts a salaried employee with formal bank statements against a market trader with strong daily cash flow but no formal payslip, showing how a loan-scoring model trained mostly on formal-sector data can unfairly score the trader as high risk through underrepresentation, not malicious intent. Students also examine real-world global examples (biased hiring tools, facial recognition error-rate gaps, healthcare risk models, postcode-based credit scoring) and learn four competing definitions of fairness — equal treatment, equal outcomes, equal opportunity, and individual fairness — that can conflict with each other, requiring a deliberate, documented choice. The topic closes with a ten-point pre-launch checklist and Nigeria-specific considerations: the informal economy, language diversity (Yoruba, Igbo, Hausa, Pidgin), connectivity gaps, and urban-rural data gaps.

**Common Mistakes:**
- Believing a model is automatically neutral or unbiased simply because it is "just math"
- Assuming that removing a sensitive field like gender from the input data eliminates bias, without considering proxy variables like postcode or spending pattern
- Treating fairness as one single, objective, universally-agreed definition rather than a deliberate choice between several valid but sometimes conflicting framings
- Assuming bias testing is a one-time pre-launch step rather than something that must be repeated as data and usage patterns change
- Underestimating how large a share of the real user base is affected by informal-economy, language-diversity, or connectivity-related fairness gaps in a Nigerian context

---

## Topic 2: Data Protection for AI Builders - NDPA 2023 & GAID 2025 Essentials

**Title:** Data Protection for AI Builders - NDPA 2023 & GAID 2025 Essentials

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will explain the core principles and lawful bases of the Nigeria Data Protection Act (NDPA) 2023, describe what the General Application and Implementation Directive (GAID) 2025 adds for practitioners, and identify the practical obligations a developer must meet before shipping an AI product that processes personal data in Nigeria.

**Description for AI:**
This topic covers Nigerian data protection law as it applies specifically to AI builders, through a legal/conceptual lesson with no coding component. Students learn that the NDPA 2023 is Nigeria's comprehensive federal data protection law, enforced by the Nigeria Data Protection Commission (NDPC), and that it applies to any organisation processing personal data of people in Nigeria regardless of where that organisation is headquartered — meaning a foreign-hosted AI API used by a Nigerian app is still within the NDPA's reach. The six core principles (lawfulness/fairness/transparency, purpose limitation, data minimisation, accuracy, storage limitation, security) are taught alongside the six lawful bases for processing data (consent, contractual necessity, legal obligation, vital interest, public interest, legitimate interest), with particular emphasis on the AI-specific nuance that consent for one purpose (like customer support) does not automatically cover another (like using that data to train a model). Students learn the enforceable data subject rights (access, correction, deletion, objection, portability, being informed) and what GAID 2025 adds operationally: registration requirements, Data Protection Officer appointment, compliance audits, Data Privacy Impact Assessments, breach notification procedures, and cross-border transfer rules — with special attention to how quickly a small AI startup can grow into "Major Importance" obligations once a feature scales. The topic ends with a practical checklist a developer should be able to answer before shipping any AI feature that touches personal data.

**Common Mistakes:**
- Believing Nigerian data protection law does not apply to a foreign-hosted AI service just because its servers are outside Nigeria
- Assuming a single blanket consent (e.g. "I agree to terms") covers every possible future use of a user's data, including AI model training
- Confusing the NDPA (the law) with GAID 2025 (the detailed operational rulebook that implements it) as if they were the same document
- Underestimating how quickly a small team can be reclassified as a Data Controller/Processor of "Major Importance," triggering stricter obligations like DPO appointment and DPIAs
- Treating data protection compliance as a legal afterthought to be addressed only after a regulator complaint, rather than a design-stage engineering responsibility

---

## Topic 3: Handling Personal Data in LLM Applications & RAG Pipelines

**Title:** Handling Personal Data in LLM Applications & RAG Pipelines

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will identify the specific points where personal data can enter an LLM or RAG pipeline — prompts, ingested documents, embeddings, vector stores, logs, and third-party APIs — and apply practical techniques (redaction, anonymisation, pseudonymisation, and safe third-party data handling) to prevent it from leaking or being mishandled.

**Description for AI:**
This topic applies the data-protection principles from Topic 2 specifically to LLM and RAG (Retrieval-Augmented Generation) systems, through an applied-conceptual lesson with no coding component. Students learn that a typical LLM/RAG application has many places personal data can hide beyond an obvious database table: the prompt itself, documents ingested for retrieval, the embeddings generated from those documents, the vector store where embeddings are searched, application logs, and the third-party API the request travels through. A key misconception addressed directly is that embeddings are "just numbers" and therefore anonymous — students learn that an embedding is a mathematical representation of the original text and remains linked to the original chunk stored alongside it, meaning a vector database of ingested customer documents carries the same obligations as any other personal data store. Students learn to distinguish redaction (masking, often reversibly), anonymisation (irreversibly removing identifiability), and pseudonymisation (replacing identifiers with a separately-keyed token), and why redacting before ingestion into a RAG pipeline is far more effective than trying to clean already-embedded and indexed data afterward. The topic also covers what a genuine deletion process must reach (original documents, embeddings, caches, logs, backups) and practical safeguards for sending data to third-party LLM APIs, such as minimising fields sent and using placeholder tokens instead of real names.

**Common Mistakes:**
- Believing that embeddings (vectors of numbers) are automatically anonymous and therefore exempt from data protection obligations
- Ingesting entire raw documents into a RAG vector store without first checking what personal data they contain
- Forgetting the vector store, caches, and logs when responding to a user's data deletion request, and only deleting from the main application database
- Logging full prompts and model responses indefinitely with no defined retention period
- Assuming a third-party LLM provider's default settings are privacy-safe without actually checking that provider's data retention and training-use terms

---

## Topic 4: International Context - GDPR & Cross-Border Data

**Title:** International Context - GDPR & Cross-Border Data

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will explain the essentials of GDPR, describe how it compares to and influenced the NDPA, and identify when using a foreign-hosted LLM API or cloud vector database constitutes a cross-border data transfer requiring a valid legal basis.

**Description for AI:**
This topic extends data protection understanding beyond Nigeria, through a legal/conceptual lesson with no coding component. Students learn that the General Data Protection Regulation (GDPR) is the EU's data protection law, applying to any organisation processing personal data of people in the EU regardless of where that organisation is based, and that it directly shaped the structure and principles of Nigeria's own NDPA — meaning a student who understands the NDPA's six principles already understands most of GDPR's core logic, with GDPR's main additional emphasis being accountability (the ability to demonstrate compliance, not just claim it). The topic explains why a Nigerian AI builder needs to care about GDPR even without EU customers: LLM API providers and cloud vector database providers are often themselves governed by GDPR-aligned terms that shape the tools being built with. The core teaching is that both GDPR and the NDPA treat cross-border data transfer as restricted by default, allowed only when adequacy, appropriate safeguards, or a specific exception applies — and that calling a foreign-hosted LLM API, or using a cloud vector database hosted outside Nigeria, is itself a cross-border transfer the moment personal data is involved, regardless of where the Nigerian company's own servers sit. Students learn practical risk-reduction habits: minimising or placeholdering personal data before it leaves the country, choosing providers with clear published transfer safeguards, preferring regional hosting, and documenting every transfer.

**Common Mistakes:**
- Assuming GDPR is irrelevant to a Nigerian AI builder simply because the product has no European customers
- Believing that because a company's own servers are located in Nigeria, calling a foreign-hosted LLM API cannot be a cross-border data transfer
- Assuming a cloud provider's published privacy policy alone fully removes the Nigerian business's own legal responsibility for lawful processing
- Believing that encrypting data in transit resolves the underlying legal cross-border transfer issue, when encryption only protects against interception, not against who has access at the destination
- Confusing the NDPA and GDPR as unrelated or competing laws rather than closely related frameworks that share almost the same core principles

---

## Topic 5: Transparency & Explainability in AI

**Title:** Transparency & Explainability in AI

**Programming Language:** None

**Coding Exercise:** No

**Learning Objective:**
Students will explain why transparency and explainability matter to both users and regulators, distinguish interpretability from explainability, apply simple techniques for making AI outputs understandable, and disclose AI use and known system limitations honestly.

**Description for AI:**
This topic closes the module's responsible-AI arc, through a conceptual lesson with no coding component, by tying together bias awareness (Topic 1), lawful data handling (Topics 2-3), and cross-border awareness (Topic 4) under the single theme of transparency. Students learn that a system can be accurate, fair, and legally compliant, and still fail its users if nobody can explain how or why it reached a conclusion — illustrated through the perspective of a declined loan applicant or a filtered-out CV candidate who reasonably wants to know why. The topic distinguishes interpretability (how directly a person can understand a model's internal logic, such as a simple decision tree) from explainability (the broader practice of providing understandable explanations for outputs, achievable even around complex, non-interpretable models like LLMs). Students learn five practical, low-effort explainability techniques: showing reasoning rather than just an answer, citing sources in RAG systems, highlighting key inputs behind a decision, using confidence indicators, and offering plain-language summaries — applied directly back to the Topic 1 loan-scoring example to contrast a bare "Application declined" with an explained decision naming specific factors and a path forward. The topic also covers good disclosure practice (clearly labelling AI-generated content, disclosing automated decision-making, avoiding designs that make AI seem human, providing a path to a human) and the value of honestly documenting known limitations rather than hiding them.

**Common Mistakes:**
- Treating interpretability and explainability as identical concepts rather than related but distinct ideas
- Assuming a complex model like an LLM can never be made explainable simply because its internal logic cannot be fully traced
- Designing a chatbot or automated system to seem human-operated without a clear AI disclosure
- Burying AI-use disclosure deep in a terms-of-service document instead of surfacing it clearly at the point of use
- Believing that documenting a system's known limitations will damage user trust, when honest documentation of limitations is what actually builds more trust than hiding them
